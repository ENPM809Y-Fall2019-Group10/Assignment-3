var searchData=
[
  ['landbasedwheeled',['LandBasedWheeled',['../classrwa3_1_1_land_based_wheeled.html#a29dfecaad52cccacee79d140639437e1',1,'rwa3::LandBasedWheeled::LandBasedWheeled(std::string name=&quot;none&quot;, int x=0, int y=0, int wheel_number=0, std::string *wheel_type=nullptr)'],['../classrwa3_1_1_land_based_wheeled.html#a4e55efe98f5e7cbac3e36977bdf436fc',1,'rwa3::LandBasedWheeled::LandBasedWheeled(const LandBasedWheeled &amp;s)']]]
];
