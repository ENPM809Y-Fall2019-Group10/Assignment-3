#include <iostream>

int main()
{
	std::cout<<"Hello ENPM809Y"<<std::endl;
	return 0;
}
